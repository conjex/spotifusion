package com.music.spotui.di

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.Color
import androidx.palette.graphics.Palette
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition

class Palette {
    companion object {
        // Cover colours already computed (process-wide): a screen opening on a known
        // cover gets its colour in the first frame instead of popping in afterwards.
        private val colors = java.util.Collections.synchronizedMap(object : java.util.LinkedHashMap<String, Color>(64, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Color>?) = size > 200
        })
        fun cachedSecond(imageUrl: String): Color? = colors["2|$imageUrl"]
        fun cachedFirst(imageUrl: String): Color? = colors["1|$imageUrl"]
    }

//    fun extractColorFromImageUrl(context: Context, imageUrl: String, onPaletteGenerated: (Palette) -> Unit) {
//        Glide.with(context)
//            .asBitmap()
//            .load(imageUrl)
//            .into(object : CustomTarget<Bitmap>() {
//                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
//                    Palette.from(resource).generate { palette ->
//                        palette?.let { onPaletteGenerated(it) }
//                    }
//                }
//
//                override fun onLoadCleared(placeholder: Drawable?) {
//                    // Handle cleanup here if necessary
//                }
//            })
//    }

    fun extractFirstColorFromImageUrl(context: Context, imageUrl: String, onColorExtracted: (Color) -> Unit) {
        val key = "1|$imageUrl"
        colors[key]?.let { onColorExtracted(it); return }
        Glide.with(context)
            .asBitmap()
            .load(imageUrl)
            .override(64, 64)
            .disallowHardwareConfig()
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    Palette.from(resource).generate { palette ->
                        val dominantColor = palette?.darkVibrantSwatch?.rgb
                        dominantColor?.let {
                            // Convert RGB color integer to ARGB color integer with full opacity
                            val argbColor = Color(it or (0xFF shl 24))
                            colors[key] = argbColor; onColorExtracted(argbColor)
                        }
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    // Handle cleanup here if necessary
                }
            })
    }
    fun extractSecondColorFromCoverUrl(context: Context, imageUrl: String, onColorExtracted: (Color) -> Unit) {
        val key = "2|$imageUrl"
        colors[key]?.let { onColorExtracted(it); return }
        Glide.with(context)
            .asBitmap()
            .load(imageUrl)
            .override(64, 64)
            .disallowHardwareConfig()
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    // Create a scaled down version of the bitmap
                    val scaledBitmap = Bitmap.createScaledBitmap(resource, 50, 50, true)

                    Palette
                        .from(scaledBitmap)
                        .generate { palette ->
                        val lightVibrantColor = palette?.mutedSwatch?.rgb
                        lightVibrantColor?.let {
                            // Convert RGB color integer to ARGB color integer with full opacity
                            val argbColor = Color(it or (0xFF shl 24))
                            colors[key] = argbColor; onColorExtracted(argbColor)
                        }
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    // Handle cleanup here if necessary
                }
            })
    }
}